<?php

/*
 | --------------------------------------------------------------------
 | App Namespace
 | --------------------------------------------------------------------
 |
 | This defines the default Namespace that is used throughout
 | CodeIgniter to refer to the Application directory. Change
 | this constant to change the namespace that all application
 | classes should use.
 |
 | NOTE: changing this will require manually modifying the
 | existing namespaces of App\* namespaced-classes.
 */
defined('APP_NAMESPACE') || define('APP_NAMESPACE', 'App');

/*
 | --------------------------------------------------------------------------
 | Composer Path
 | --------------------------------------------------------------------------
 |
 | The path that Composer's autoload file is expected to live. By default,
 | the vendor folder is in the Root directory, but you can customize that here.
 */
defined('COMPOSER_PATH') || define('COMPOSER_PATH', ROOTPATH . 'vendor/autoload.php');

/*
 |--------------------------------------------------------------------------
 | Timing Constants
 |--------------------------------------------------------------------------
 |
 | Provide simple ways to work with the myriad of PHP functions that
 | require information to be in seconds.
 */
defined('SECOND') || define('SECOND', 1);
defined('MINUTE') || define('MINUTE', 60);
defined('HOUR') || define('HOUR', 3600);
defined('DAY') || define('DAY', 86400);
defined('WEEK') || define('WEEK', 604800);
defined('MONTH') || define('MONTH', 2_592_000);
defined('YEAR') || define('YEAR', 31_536_000);
defined('DECADE') || define('DECADE', 315_360_000);

// $database = 'hml_leitura';
$database = 'dev_hform';
defined('DEBUG_MY_PRINT') or define('DEBUG_MY_PRINT', true);

/*
 | --------------------------------------------------------------------------
 | Exit Status Codes
 | --------------------------------------------------------------------------
 |
 | Used to indicate the conditions under which the script is exit()ing.
 | While there is no universal standard for error codes, there are some
 | broad conventions.  Three such conventions are mentioned below, for
 | those who wish to make use of them.  The CodeIgniter defaults were
 | chosen for the least overlap with these conventions, while still
 | leaving room for others to be defined in future versions and user
 | applications.
 |
 | The three main conventions used for determining exit status codes
 | are as follows:
 |
 |    Standard C/C++ Library (stdlibc):
 |       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
 |       (This link also contains other GNU-specific conventions)
 |    BSD sysexits.h:
 |       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
 |    Bash scripting:
 |       http://tldp.org/LDP/abs/html/exitcodes.html
 |
 */
defined('EXIT_SUCCESS') || define('EXIT_SUCCESS', 0);        // no errors
defined('EXIT_ERROR') || define('EXIT_ERROR', 1);          // generic error
defined('EXIT_CONFIG') || define('EXIT_CONFIG', 3);         // configuration error
defined('EXIT_UNKNOWN_FILE') || define('EXIT_UNKNOWN_FILE', 4);   // file not found
defined('EXIT_UNKNOWN_CLASS') || define('EXIT_UNKNOWN_CLASS', 5);  // unknown class
defined('EXIT_UNKNOWN_METHOD') || define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT') || define('EXIT_USER_INPUT', 7);     // invalid user input
defined('EXIT_DATABASE') || define('EXIT_DATABASE', 8);       // database error
defined('EXIT__AUTO_MIN') || define('EXIT__AUTO_MIN', 9);      // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX') || define('EXIT__AUTO_MAX', 125);    // highest automatically-assigned error code

/*
Servidor: Urudocampo_BDH
IP: 10.11.63.137
Owner: QLIKADMIN
Senha: MsqlSRzaBlala323@
database: QLIKADMIN
DBDriver: MySQLi
Porta: 3306
*/
defined('EAE0ADB11B32465EB5FF5501DD406F94') || define('EAE0ADB11B32465EB5FF5501DD406F94', '10.11.63.137'); // hostname: 10.11.63.137
defined('D253F945B3F717EEBE21BCA089A6BB79') || define('D253F945B3F717EEBE21BCA089A6BB79', 'QLIKADMIN'); // username: QLIKADMIN
defined('E3182D64AA374374F24C4D3E9217D56E') || define('E3182D64AA374374F24C4D3E9217D56E', 'MsqlSRzaBlala323@'); // password: MsqlSRzaBlala323@
defined('C3448EBD9111BD40815EC866DE418F0F') || define('C3448EBD9111BD40815EC866DE418F0F', 'Urudocampo_BDH'); // database: Urudocampo_BDH
defined('AF68B0CC7D9E15C382644D04FD59A2F3') || define('AF68B0CC7D9E15C382644D04FD59A2F3', 'MySQLi'); // DBDriver: MySQLi
defined('E1F7A9ED642A8741F1EB9A487374A2EF') || define('E1F7A9ED642A8741F1EB9A487374A2EF', 3306); // port: 3306

/*
Servidor: Urudocampo_BDH
IP: 10.11.63.137
Usuário Leitura/Escrita: QLIKADMIN_int02
Senha: jOzC4D483vVv2LA@
database: QLIKADMIN
DBDriver: MySQLi
Porta: 3306
*/
defined('C8BEF858BDCE54C21F35BDC43E81A150') || define('C8BEF858BDCE54C21F35BDC43E81A150', '10.11.63.137'); // hostname: 10.11.63.137
defined('C174B587EA1008FF7C6E1872CB6C0FB4') || define('C174B587EA1008FF7C6E1872CB6C0FB4', 'QLIKADMIN_int02'); // username: QLIKADMIN_int02
defined('EA40262334A43E4AB2BC52E0480725AC') || define('EA40262334A43E4AB2BC52E0480725AC', 'jOzC4D483vVv2LA@'); // password: jOzC4D483vVv2LA@
defined('AF9F9C8E90813B800DEF96166B81C8C8') || define('AF9F9C8E90813B800DEF96166B81C8C8', 'QLIKADMIN'); // database: QLIKADMIN
defined('ED5141DD3EFBB6231A0C765D9A9BCD0D') || define('ED5141DD3EFBB6231A0C765D9A9BCD0D', 'MySQLi'); // DBDriver: MySQLi
defined('ED5141DD3EFBB6231A0C765D9A9BCD0D') || define('ED5141DD3EFBB6231A0C765D9A9BCD0D', 3306); // port: 3306

/*
Servidor: Urudocampo_BDH
IP: 10.11.63.137
Usuário Leitura: QLIKADMIN_int01
Senha: OrclzB3sql72v1a@
database: QLIKADMIN
DBDriver: MySQLi
Porta: 3306
*/
defined('C67FA34A6FD58618201905D38B72ADFE') || define('C67FA34A6FD58618201905D38B72ADFE', '10.11.63.137'); // hostname: 10.11.63.137
defined('C74652C4867D06726B56C7025F8DDF80') || define('C74652C4867D06726B56C7025F8DDF80', 'QLIKADMIN_int01'); // username: QLIKADMIN_int01
defined('E80FFBEDC1112E960F287F54B4BC2FEA') || define('E80FFBEDC1112E960F287F54B4BC2FEA', 'OrclzB3sql72v1a@'); // password: OrclzB3sql72v1a@
defined('D0D359AA567D3B518405C3E534C72088') || define('D0D359AA567D3B518405C3E534C72088', 'QLIKADMIN'); // database: QLIKADMIN
defined('C347F2080F5E36125358B6651FF44FBD') || define('C347F2080F5E36125358B6651FF44FBD', 'MySQLi'); // DBDriver: MySQLi
defined('D2561ED3A712EB14C6D02A83FCBEA6B4') || define('D2561ED3A712EB14C6D02A83FCBEA6B4', 3306); // port: 3306

/*
Servidor: Lavadeira
IP: 10.11.30.33
Usuário Leitura/Escrita: QLIKADMIN_int02
Senha: BZCa43XBCAACv5a@
database: QLIKADMIN
DBDriver: MySQLi
Porta: 3306
*/
defined('F94E47C98818009808D991ED4F1CEC0C') || define('F94E47C98818009808D991ED4F1CEC0C', '10.11.30.33'); // hostname: 10.11.30.33
defined('D8721DF6E66706B9079767C782F164DA') || define('D8721DF6E66706B9079767C782F164DA', 'QLIKADMIN_int02'); // username: QLIKADMIN_int02
defined('F329F0BA7F04B64180BCED997216D7E5') || define('F329F0BA7F04B64180BCED997216D7E5', 'BZCa43XBCAACv5a@'); // password: BZCa43XBCAACv5a@
defined('B04058619F16A9D14980F7B0BA083053') || define('B04058619F16A9D14980F7B0BA083053', 'QLIKADMIN'); // database: QLIKADMIN
defined('E2CFB14558C6E64FFFEC9037F508B866') || define('E2CFB14558C6E64FFFEC9037F508B866', 'DBDriver'); // DBDriver: MySQLi
defined('B04058619F16A9D14980F7B0BA083053') || define('B04058619F16A9D14980F7B0BA083053', 'port'); // port: 3306

/*
Servidor: Lavadeira
IP: 10.11.30.33
Usuário Leitura: QLIKADMIN_int01
Senha: AzFBB34XC378v1a@
database: QLIKADMIN
DBDriver: MySQLi
Porta: 3306
*/
defined('BFD57DAECD4B39930E9C132DEAC07908') || define('BFD57DAECD4B39930E9C132DEAC07908', '10.11.30.33'); // hostname: 10.11.30.33
defined('A5F4009A7AC73A7B3D483E1D80FE280C') || define('A5F4009A7AC73A7B3D483E1D80FE280C', 'QLIKADMIN_int01'); // username: QLIKADMIN_int01
defined('A13698110FB94177079DC49BF13B6250') || define('A13698110FB94177079DC49BF13B6250', 'AzFBB34XC378v1a@'); // password: AzFBB34XC378v1a@
defined('A590192688DE70573C02974BABDECA6D') || define('A590192688DE70573C02974BABDECA6D', 'QLIKADMIN'); // database: QLIKADMIN
defined('F1CFCB63C48D57F12AAFE0611F95FC2A') || define('F1CFCB63C48D57F12AAFE0611F95FC2A', 'valor'); // DBDriver: MySQLi
defined('CEABB66310BE3E6488CC6149D1D5AB2A') || define('CEABB66310BE3E6488CC6149D1D5AB2A', 'valor'); // port: 3306
/*
Servidor: Urudocampo_BDH
IP: 10.11.63.137
Owner: Intranet_DEGASE
Senha: 3vaSE4L@NkN7HlWTFj
DadaBase: Intranet_DEGASE
DBDriver: MySQLi
Porta: 3306
*/
defined('CC7B12BA9F6CA15869CC07DEDF1CF7BD') || define('CC7B12BA9F6CA15869CC07DEDF1CF7BD', '10.11.63.137'); // hostname: 10.11.63.137
defined('F6875467791C9754361DC2E9B9826C78') || define('F6875467791C9754361DC2E9B9826C78', 'Intranet_DEGASE'); // username: Intranet_DEGASE
defined('B1D2A1FBFCE3F60E8048C7C2ECD38241') || define('B1D2A1FBFCE3F60E8048C7C2ECD38241', '3vaSE4L@NkN7HlWTFj'); // password: 3vaSE4L@NkN7HlWTFj
defined('D4B655D1531928E6944C133F35D7AB0F') || define('D4B655D1531928E6944C133F35D7AB0F', 'Intranet_DEGASE'); // database: Intranet_DEGASE
defined('FB7D725D281DA653895BED7D1CC6C017') || define('FB7D725D281DA653895BED7D1CC6C017', 'MySQLi'); // DBDriver: MySQLi
defined('DF0B7CA84EECE0EA9267FE53FE769C35') || define('DF0B7CA84EECE0EA9267FE53FE769C35', 3306); // port: 3306
/*
Servidor: Urudocampo_BDH
IP: 10.11.63.137
Usuário Leitura/Escrita: Intranet_DEGASE_int02
Senha: ZxG18vF@TphO3yvk96
DadaBase: Intranet_DEGASE
DBDriver: MySQLi
Porta: 3306
*/
defined('F09264337B7F9365EBF16162D59FB6A0') || define('F09264337B7F9365EBF16162D59FB6A0', 'valor'); // hostname: 
defined('DCED82264CBD800053878403CF7E61DE') || define('DCED82264CBD800053878403CF7E61DE', 'valor'); // username: 
defined('D4DE647B53D14F5E3A2CED7D509D2EB1') || define('D4DE647B53D14F5E3A2CED7D509D2EB1', 'valor'); // password: 
defined('C5E822807C4F85071719914F0A418729') || define('C5E822807C4F85071719914F0A418729', 'valor'); // database: 
defined('BB86EF917A8EDB1B8519016E419A77E0') || define('BB86EF917A8EDB1B8519016E419A77E0', 'MySQLi'); // DBDriver: MySQLi
defined('F2E6EC63F1D292DEEF135AD34E914444') || define('F2E6EC63F1D292DEEF135AD34E914444', 3306); // port: 3306
/*
Servidor: Urudocampo_BDH
IP: 10.11.63.137
Usuário Leitura: Intranet_DEGASE_int01
Senha: tG7@QaNJCWSUU5PoHj
DadaBase: Intranet_DEGASE
DBDriver: MySQLi
Porta: 3306
*/

defined('A9FB502A0FE04C97EE78BA29DB489FBA') || define('A9FB502A0FE04C97EE78BA29DB489FBA', '10.11.63.137'); // hostname: 10.11.63.137
defined('C295021637A9AF9055EE8E4876728BDA') || define('C295021637A9AF9055EE8E4876728BDA', 'Intranet_DEGASE_int01'); // username: Intranet_DEGASE_int01
defined('BB4637745121BF1A2D31CCDDAB3F520D') || define('BB4637745121BF1A2D31CCDDAB3F520D', 'tG7@QaNJCWSUU5PoHj'); // password: tG7@QaNJCWSUU5PoHj
defined('AD07D22805A6BF852C07053A59AC42F3') || define('AD07D22805A6BF852C07053A59AC42F3', 'Intranet_DEGASE'); // database: Intranet_DEGASE
defined('C60B5B89657C2373FE6CAF94B8FA7663') || define('C60B5B89657C2373FE6CAF94B8FA7663', 'MySQLi'); // DBDriver: MySQLi
defined('E549318C7C3D5224A5BD6E04FA43D6FA') || define('E549318C7C3D5224A5BD6E04FA43D6FA', 3306); // port: 3306
/*
IP: 127.0.0.1
Servidor: mysql-intranetdeegase
Usuário Local: root
Senha: pass123
DadaBase: intranetdegase
DBDriver: MySQLi
Porta: 3306
*/
defined('BE314B83BF05F6F1E74C8DD99F2880FC') || define('BE314B83BF05F6F1E74C8DD99F2880FC', 'mysql-intranetdeegase'); // hostname: mysql-intranetdeegase
defined('CF6653F62C741E540C2B77E51D3C4887') || define('CF6653F62C741E540C2B77E51D3C4887', 'root'); // username: root
defined('B024842ACCA9CF6B4910BB859ED91D58') || define('B024842ACCA9CF6B4910BB859ED91D58', 'pass123'); // password: pass123
defined('B92397F8AD694DC3A41AEF2FD91F05A6') || define('B92397F8AD694DC3A41AEF2FD91F05A6', 'intranetdegase'); // database: intranetdegase
defined('AB74804868EF19DE67DF19530AB0E818') || define('AB74804868EF19DE67DF19530AB0E818', 'MySQLi'); // DBDriver: MySQLi
defined('B8BA0DE78450B7D5367802ECF58DA681') || define('B8BA0DE78450B7D5367802ECF58DA681', 3306); // port: 3306
/*
IP: 127.0.0.1
Servidor: mysql-hform
Usuário Local: root
Senha: pass123
DadaBase: hform
DBDriver: MySQLi
Porta: 3306
*/
defined('AC3A6AFC41CEE504EF17CAB2E279F349') || define('AC3A6AFC41CEE504EF17CAB2E279F349', 'mysql-hform'); // hostname: mysql-hform
defined('B6B82370878BE24D70AE51EFA7B753DE') || define('B6B82370878BE24D70AE51EFA7B753DE', 'root'); // username: root
defined('C4606CBEFD602055ED894D6FF5F6454C') || define('C4606CBEFD602055ED894D6FF5F6454C', 'pass123'); // password: pass123
defined('DA9A66CCDE4EB42E308A187FF5EAA7A4') || define('DA9A66CCDE4EB42E308A187FF5EAA7A4', 'hform'); // database: hform
defined('A9821CA593DA36A41CA0C89C894FA379') || define('A9821CA593DA36A41CA0C89C894FA379', 'MySQLi'); // DBDriver: MySQLi
defined('D7CA8286BA4D1A81375713C27B431E48') || define('D7CA8286BA4D1A81375713C27B431E48', 3306); // port: 3306
/*
IP: 127.0.0.1
Servidor: mysql-qlikadmin
Usuário Local: root
Senha: pass123
DadaBase: qlikadmin
DBDriver: MySQLi
Porta: 3306
*/
defined('DDEBF4FEB3047FF69D2924758D83EC53') || define('DDEBF4FEB3047FF69D2924758D83EC53', 'mysql-qlikadmin'); // hostname: mysql-qlikadmin
defined('F221DDE1BCE1DC4D4F9EB5BA0798CF9E') || define('F221DDE1BCE1DC4D4F9EB5BA0798CF9E', 'root'); // username: root
defined('B7067E7990E028B4CC95FD73CB33DFFA') || define('B7067E7990E028B4CC95FD73CB33DFFA', 'pass123'); // password: pass123
defined('C9A5A2384BCB1BAB8B5B8D2AC86AA51D') || define('C9A5A2384BCB1BAB8B5B8D2AC86AA51D', 'qlikadmin'); // database: qlikadmin
defined('CB6EB036688C4C4AE683C9A85573B811') || define('CB6EB036688C4C4AE683C9A85573B811', 'MySQLi'); // DBDriver: MySQLi
defined('A9E4ACDB3551CFAD6561687E0B8C1012') || define('A9E4ACDB3551CFAD6561687E0B8C1012', 3306); // port: 3306
/*
IP: 127.0.0.1
Servidor: mysql-sgc
Usuário Local: root
Senha: pass123
DadaBase: sgc
DBDriver: MySQLi
Porta: 3306
*/
defined('BAC601E829A2D481A0E6A8971F7E8319') || define('BAC601E829A2D481A0E6A8971F7E8319', 'mysql-sgc'); // hostname: mysql-sgc
defined('AA05AEB7C2C83EC5CC5FDE98274A5C0D') || define('AA05AEB7C2C83EC5CC5FDE98274A5C0D', 'root'); // username: root
defined('DB66A799AFAF5A6523BBDEAE1178D2A7') || define('DB66A799AFAF5A6523BBDEAE1178D2A7', 'pass123'); // password: pass123
defined('E0711BFA8C3A919A6497DA8931520350') || define('E0711BFA8C3A919A6497DA8931520350', 'sgc'); // database: sgc
defined('DCB6D081B8DAE09607F3E7A8AD5D7191') || define('DCB6D081B8DAE09607F3E7A8AD5D7191', 'MySQLi'); // DBDriver: MySQLiMySQLi
defined('B22F51CB7599B1D4CA0AAA0465D46AE5') || define('B22F51CB7599B1D4CA0AAA0465D46AE5', 3306); // port: 3306
/*
IP: 127.0.0.1
Servidor: mysql-sgp
Usuário Local: root
Senha: pass123
DadaBase: sgp
DBDriver: MySQLi
Porta: 3306
*/
defined('BFE13EDE23F40A6B4E2B68FB9B5E7227') || define('BFE13EDE23F40A6B4E2B68FB9B5E7227', 'mysql-sgp'); // hostname: mysql-sgp
defined('DBD4F51CE226381032D54C90A0D0ACA4') || define('DBD4F51CE226381032D54C90A0D0ACA4', 'root'); // username: root
defined('EDB62190B22B578D807DFFFE4CF9805B') || define('EDB62190B22B578D807DFFFE4CF9805B', 'pass123'); // password: pass123
defined('E6CBF9FF07F348AACDB49EC22C8B854F') || define('E6CBF9FF07F348AACDB49EC22C8B854F', 'sgp'); // database: sgp
defined('C56F631FC263053C5B44ACC7998342D0') || define('C56F631FC263053C5B44ACC7998342D0', 'MySQLi'); // DBDriver: MySQLi
defined('FFF256B8D43212B581D7D7B7ECBC0B06') || define('FFF256B8D43212B581D7D7B7ECBC0B06', 3306); // port: 3306
/*
Servidor: 127.0.0.1
IP: 127.0.0.1
Usuário Local: root
Senha: pass123
DadaBase: hform
DBDriver: MySQLi
Porta: 3306
*/
/*
defined('xx') || define('xx', 'valor'); // hostname: 
defined('xx') || define('xx', 'valor'); // username: 
defined('xx') || define('xx', 'valor'); // password: 
defined('xx') || define('xx', 'valor'); // database: 
defined('xx') || define('xx', 'MySQLi'); // DBDriver: MySQLi
defined('xx') || define('xx', 3306); // port: 3306
*/

switch ($database) {
    case 'hml_leitura':
        defined('DATABASE_CONNECTION_QLIKADMIN') || define('DATABASE_CONNECTION_QLIKADMIN', 'hml_qlikadmin_leitura');
        defined('DATABASE_CONNECTION_INTRANET_DEGASE') || define('DATABASE_CONNECTION_INTRANET_DEGASE', 'hml_intranet_degase_leitura');
        break;
        
        case 'dev_hform':
            defined('DATABASE_CONNECTION_INTRANETDEDGASE') || define('DATABASE_CONNECTION_INTRANETDEDGASE', 'dev_intranetdegase_hform');
            defined('DATABASE_CONNECTION_QLIKADMIN') || define('DATABASE_CONNECTION_QLIKADMIN', 'dev_qlikadmin_hform');
            defined('DATABASE_CONNECTION_HFORM') || define('DATABASE_CONNECTION_HFORM', 'dev_hform');
            defined('DATABASE_CONNECTION_SGC') || define('DATABASE_CONNECTION_SGC', 'dev_sgc_hform');
            defined('DATABASE_CONNECTION_SGP') || define('DATABASE_CONNECTION_SGP', 'dev_sgp_hform');
        break;

    case 3:
        echo "Você selecionou a opção 3: Atualizar registro existente";
        break;

    case 4:
        echo "Você selecionou a opção 4: Excluir registro";
        break;

    default:
        echo "Opção inválida! Por favor, selecione um número entre 1 e 4";
}